
package projetoingresso;

/**
 *
 * @author Charllys e Jonas
 */
public class IngressoVIP extends Ingresso {
      
    public float valor() {
        return this.getValor() + 10.00f;
    }
   
    
    
    
}

